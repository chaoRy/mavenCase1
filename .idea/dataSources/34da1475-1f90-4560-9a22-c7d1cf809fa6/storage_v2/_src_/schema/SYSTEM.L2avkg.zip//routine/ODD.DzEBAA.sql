create function odd(Value in integer) return boolean is
  Result boolean;
begin
  
  Result:=not Even(Value);
  return(Result);
end odd;
/

