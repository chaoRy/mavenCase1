create function Even(Value in integer) return boolean is
  Result boolean;
begin
  Result :=(Value mod 2=0);
  return(Result);
end Even;
/

