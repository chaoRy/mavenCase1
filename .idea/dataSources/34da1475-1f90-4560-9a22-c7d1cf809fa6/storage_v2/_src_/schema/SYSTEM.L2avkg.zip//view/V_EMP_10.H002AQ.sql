create view V_EMP_10 as
  SELECT empno no,ename name,sal salary,deptno dno
from emp
where deptno=10
WITH READ ONLY
/

