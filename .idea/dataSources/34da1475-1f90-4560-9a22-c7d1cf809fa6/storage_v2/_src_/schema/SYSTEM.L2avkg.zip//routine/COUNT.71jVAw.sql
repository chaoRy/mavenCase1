create function count() return integer is
  Result integer;
begin
  Result:=Value(select count(*) from user_tables);
  return(Result);
end count;
/

