create view V_EMP_SALARY as
  select d.deptno,d.dname,max(e.sal) max_sal,
                        min(e.sal) min_sal,
                        avg(e.sal) avg_sal,
                        sum(e.sal) sum_sal
from emp e,dept d
where e.deptno=d.deptno
group by d.deptno,d.dname
/

